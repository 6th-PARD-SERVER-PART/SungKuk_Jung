package com.pard.server.hw4_sungkukjung.comment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

public class CommentRequest {
    @Getter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class CreateComment {
        private Long userId;
        private Long postId;
        private String content; // Content is defined as String, required
    }

    @Getter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UpdateComment {
        private String content; // Only content can be updated
    }
}