package com.pard.server.hw4_sungkukjung.post;

import com.pard.server.hw4_sungkukjung.user.User;
import com.pard.server.hw4_sungkukjung.user.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class PostService {
    private final PostRepository postRepository;
    private final UserRepository userRepository;

    @Value("${file.upload-dir:uploads/posts}")
    private String uploadDir;

    @Transactional
    public void createPost(PostRequest.NewPost postRequest, MultipartFile file) {
        User user = userRepository.findById(postRequest.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found with id: " + postRequest.getUserId()));

        String fileUrl = saveFileAndGetUrl(file);

        Post post = Post.builder()
                .user(user)
                .title(postRequest.getTitle())
                .description(postRequest.getDescription())
                .content(postRequest.getContent())
                .fileUploadUrl(fileUrl)
                .build();
        postRepository.save(post);
    }

    @Transactional
    public PostResponse.ViewPost getPostById(Long postId) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new RuntimeException("Post not found with id: " + postId));
        post.incrementViewsCount();
        postRepository.save(post);

        return convertToViewPost(post);
    }

    @Transactional
    public List<PostResponse.DashboardPostInfo> getAllPosts() {
        List<Post> posts = postRepository.findAllByOrderByDateCreatedDesc();
        return posts.stream()
                .map(this::convertToDashboardPostInfo)
                .toList();
    }

    @Transactional
    public List<PostResponse.DashboardPostInfo> getPostsByUsername(String username) {
        List<Post> posts = postRepository.findByUserUsernameOrderByDateCreatedDesc(username);
        return posts.stream()
                .map(this::convertToDashboardPostInfo)
                .toList();
    }

    @Transactional
    public void updatePost(Long postId, PostRequest.UpdatePost postUpdate, MultipartFile file) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new RuntimeException("Post not found with id: " + postId));

        post.updatePost(postUpdate);

        if (file != null && !file.isEmpty()) {
            // Delete old file if exists
            if (post.getFileUploadUrl() != null) {
                deleteFile(post.getFileUploadUrl());
            }
            String newFileUrl = saveFileAndGetUrl(file);
            post.setFileUploadUrl(newFileUrl);
        }

        postRepository.save(post);
    }

    @Transactional
    public void deletePost(Long postId) {
        Post post = postRepository.findById(postId)
                .orElseThrow(() -> new RuntimeException("Post not found with id: " + postId));

        // Delete file if exists
        if (post.getFileUploadUrl() != null) {
            deleteFile(post.getFileUploadUrl());
        }

        postRepository.deleteById(postId);
    }

    private PostResponse.ViewPost convertToViewPost(Post post) {
        return PostResponse.ViewPost.builder()
                .id(post.getId())
                .username(post.getUser().getUsername())
                .userProfilePicture(post.getUser().getProfilePicture())
                .title(post.getTitle())
                .description(post.getDescription())
                .content(post.getContent())
                .fileUploadUrl(post.getFileUploadUrl())
                .dateCreated(post.getDateCreated())
                .dateModified(post.getDateModified())
                .likesCount(post.getLikesCount())
                .commentsCount(post.getCommentsCount())
                .viewsCount(post.getViewsCount())
                .build();
    }

    private PostResponse.DashboardPostInfo convertToDashboardPostInfo(Post post) {
        return PostResponse.DashboardPostInfo.builder()
                .id(post.getId())
                .title(post.getTitle())
                .description(post.getDescription())
                .likesCount(post.getLikesCount())
                .commentsCount(post.getCommentsCount())
                .viewsCount(post.getViewsCount())
                .build();
    }

    private String saveFileAndGetUrl(MultipartFile file) {
        if (file == null || file.isEmpty()) {
            return null;
        }

        try {
            String originalFilename = file.getOriginalFilename();
            String extension = originalFilename != null && originalFilename.contains(".")
                    ? originalFilename.substring(originalFilename.lastIndexOf("."))
                    : "";
            String uniqueFilename = UUID.randomUUID().toString() + extension;

            Path uploadPath = Paths.get(uploadDir);
            if (!Files.exists(uploadPath)) {
                Files.createDirectories(uploadPath);
            }

            Path filePath = uploadPath.resolve(uniqueFilename);
            Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

            return "/uploads/" + uniqueFilename;

        } catch (IOException e) {
            throw new RuntimeException("Failed to store file: " + e.getMessage(), e);
        }
    }

    private void deleteFile(String fileUrl) {
        if (fileUrl == null || !fileUrl.startsWith("/uploads/")) {
            return;
        }

        try {
            String filename = fileUrl.substring("/uploads/".length());
            Path filePath = Paths.get(uploadDir).resolve(filename);
            Files.deleteIfExists(filePath);
        } catch (IOException e) {
            System.err.println("Failed to delete file: " + e.getMessage());
        }
    }
}