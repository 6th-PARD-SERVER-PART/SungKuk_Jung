package com.pard.server.hw4_sungkukjung.post;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

public class PostRequest {
    @Getter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class NewPost {
        private Long userId;
        private String title;
        private String description;
        private String content;
        private String fileUploadUrl;
    }

    @Getter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UpdatePost {
        private String title;
        private String description;
        private String content;
        private String fileUploadUrl;
    }
}
