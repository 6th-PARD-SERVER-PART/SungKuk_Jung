package com.pard.server.hw4_sungkukjung.user;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/user")
public class UserController {
    private final UserService userService;

    @PostMapping("/sign-up")
    public ResponseEntity<?> signUp(@RequestBody UserRequest.UserSignUp signUpRequest) {
        try {
            userService.signUp(signUpRequest);
            // Return 200 OK with a message on success
            return ResponseEntity.ok("User registered successfully.");
        } catch (IllegalArgumentException e) {
            // Catch validation errors (like username/email already exists)
            // and return 400 BAD REQUEST with the error message
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(e.getMessage());
        }
    }

    @PostMapping("/log-in")
    public ResponseEntity<?> logIn(@RequestBody UserRequest.UserLogIn logInRequest) {
        try {
            UserResponse.UserLogInResponse response = userService.logIn(logInRequest);
            return ResponseEntity.ok(response);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(e.getMessage());
        }
    }

    @GetMapping("/{username}")
    public ResponseEntity<?> findByUsername(@PathVariable String username) {
        try {
            UserResponse.UserSearched user = userService.searchUser(username);
            return ResponseEntity.ok(user);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }

    @GetMapping("/{username}/activity")
    public ResponseEntity<?> findUserActivity(@PathVariable String username) {
        try {
            UserResponse.UserActivity activity = userService.getUserActivity(username);
            return ResponseEntity.ok(activity);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(e.getMessage());
        }
    }

    @PatchMapping("/{id}")
    public void updateUserInfo(@PathVariable Long id, @RequestBody UserRequest.UserUpdate updateRequest) {
        userService.updateUserInfo(id, updateRequest);
    }

    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable Long id) {
        userService.deleteUser(id);
    }

    @GetMapping("")
    public List<UserResponse.UserSearched> findAll() {
        return userService.getAllUsers();
    }
}
