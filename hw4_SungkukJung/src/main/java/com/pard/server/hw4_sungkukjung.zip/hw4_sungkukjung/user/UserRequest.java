package com.pard.server.hw4_sungkukjung.user;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

public class UserRequest {

    @Getter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UserSignUp {
        private String profilePicture;
        private String name;
        private String username;
        private String password;
        private String email;
    }

    @Getter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UserLogIn {
        private String username;
        private String password;
    }

    @Getter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UserUpdate {
        private String profilePicture;
        private String name;
        private String email;
        private String password; // Optional: for password change
    }
}
