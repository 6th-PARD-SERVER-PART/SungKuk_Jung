package com.pard.server.hw4_sungkukjung;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hw4SungkukJungApplication {

    public static void main(String[] args) {
        SpringApplication.run(Hw4SungkukJungApplication.class, args);
    }

}
