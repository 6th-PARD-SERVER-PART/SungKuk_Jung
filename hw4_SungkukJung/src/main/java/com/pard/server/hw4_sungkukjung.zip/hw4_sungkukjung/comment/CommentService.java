package com.pard.server.hw4_sungkukjung.comment;

import com.pard.server.hw4_sungkukjung.post.Post;
import com.pard.server.hw4_sungkukjung.post.PostRepository;
import com.pard.server.hw4_sungkukjung.user.User;
import com.pard.server.hw4_sungkukjung.user.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CommentService {
    private final CommentRepository commentRepository;
    private final PostRepository postRepository;
    private final UserRepository userRepository;

    @Transactional
    public void createComment(CommentRequest.CreateComment commentRequest) {
        User user = userRepository.findById(commentRequest.getUserId())
                .orElseThrow(() -> new RuntimeException("User not found with id: " + commentRequest.getUserId()));

        Post post = postRepository.findById(commentRequest.getPostId())
                .orElseThrow(() -> new RuntimeException("Post not found with id: " + commentRequest.getPostId()));

        Comment comment = Comment.builder()
                .content(commentRequest.getContent())
                .user(user)
                .post(post)
                .build();
        commentRepository.save(comment);
    }

    @Transactional
    public List<CommentResponse.ViewComment> getCommentsByPostId(Long postId) {
        // Checks if the post exists (optional, but good practice)
        if (!postRepository.existsById(postId)) {
            throw new RuntimeException("Post not found with id: " + postId);
        }

        List<Comment> comments = commentRepository.findByPostIdOrderByDateCommentedAsc(postId);
        return comments.stream()
                .map(this::convertToViewComment)
                .collect(Collectors.toList());
    }

    @Transactional
    public void updateComment(Long commentId, CommentRequest.UpdateComment commentUpdate) {
        Comment comment = commentRepository.findById(commentId)
                .orElseThrow(() -> new RuntimeException("Comment not found with id: " + commentId));
        comment.updateComment(commentUpdate);
        commentRepository.save(comment);
    }

    @Transactional
    public void deleteComment(Long commentId) {
        if (!commentRepository.existsById(commentId)) {
            throw new RuntimeException("Comment not found with id: " + commentId);
        }
        commentRepository.deleteById(commentId);
    }

    private CommentResponse.ViewComment convertToViewComment(Comment comment) {
        return CommentResponse.ViewComment.builder()
                .id(comment.getId())
                .postId(comment.getPost().getId())
                .content(comment.getContent())
                .dateCommented(comment.getDateCommented())
                .dateModified(comment.getDateModified())
                .username(comment.getUser().getUsername())
                .userProfilePicture(comment.getUser().getProfilePicture())
                .build();
    }
}