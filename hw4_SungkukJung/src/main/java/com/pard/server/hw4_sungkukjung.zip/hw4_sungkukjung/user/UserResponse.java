package com.pard.server.hw4_sungkukjung.user;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;


public class UserResponse {
    @Getter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UserInfo {
        private Long id;
        private String profilePicture;
        private String name;
        private String username;
        private String email;
    }

    @Getter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UserLogInResponse {
        private Long id;
        private String username;
        private String name;
        private String message;
    }

    @Getter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UserSearched {
        private String profilePicture;
        private String name;
        private String username;
        private int postsCount;
    }

    @Getter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UserActivity {
        private String username;
        private int postsCount;
        private int likesCount;
        private int commentsCount;
    }
}
