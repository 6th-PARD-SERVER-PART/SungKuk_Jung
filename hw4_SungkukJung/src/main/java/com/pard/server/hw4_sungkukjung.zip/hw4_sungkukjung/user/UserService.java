package com.pard.server.hw4_sungkukjung.user;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;

    public void signUp(UserRequest.UserSignUp signUpRequest) {
        if (userRepository.findByUsername(signUpRequest.getUsername()).isPresent()) {
            throw new IllegalArgumentException("Username already exists.");
        }
        if (userRepository.findByEmail(signUpRequest.getEmail()).isPresent()) {
            throw new IllegalArgumentException("Email already registered.");
        }

        User user = User.builder()
                .profilePicture(signUpRequest.getProfilePicture())
                .name(signUpRequest.getName())
                .username(signUpRequest.getUsername())
                .password(signUpRequest.getPassword())
                .email(signUpRequest.getEmail())
                .build();
        userRepository.save(user);
    }

    public UserResponse.UserLogInResponse logIn(UserRequest.UserLogIn loginRequest) {
        User user = userRepository.findByUsername(loginRequest.getUsername())
                .orElseThrow(() -> new IllegalArgumentException("Username not found."));
        if (!user.getPassword().equals(loginRequest.getPassword())) {
            throw new IllegalArgumentException("Password does not match.");
        }
        return UserResponse.UserLogInResponse.builder()
                .id(user.getId())
                .username(user.getUsername())
                .name(user.getName())
                .message("Login Successful.")
                .build();

    }


    public UserResponse.UserSearched searchUser(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException(("User not found with username: " + username)));
        return UserResponse.UserSearched.builder()
                .profilePicture(user.getProfilePicture())
                .name(user.getName())
                .username(user.getUsername())
                .postsCount(user.getPostsCount())
                .build();
    }

    public UserResponse.UserActivity getUserActivity(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException(("User not found with username: " + username)));
        return UserResponse.UserActivity.builder()
                .username(user.getUsername())
                .postsCount(user.getPostsCount())
                .likesCount(user.getLikesCount())
                .commentsCount(user.getCommentsCount())
                .build();
    }

    @Transactional
    public void updateUserInfo(Long userId, UserRequest.UserUpdate userUpdateRequest) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException(("User not found with userId: " + userId)));
        user.updateUser(userUpdateRequest);
        userRepository.save(user);
    }

    public void deleteUser(Long userId) {
        if(!userRepository.existsById(userId)) {
            throw new RuntimeException(("User not found with userId: " + userId));
        }
        userRepository.deleteById(userId);
    }

    public List<UserResponse.UserSearched> getAllUsers() {
        List<User> users = userRepository.findAllByOrderByIdDesc();
        return users.stream().map( user ->
                UserResponse.UserSearched.builder()
                        .profilePicture(user.getProfilePicture())
                        .name(user.getName())
                        .username(user.getUsername())
                        .postsCount(user.getPostsCount())
                        .build()
        ).toList();
    }
}
