package com.pard.server.hw4_sungkukjung.comment;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CommentRepository  extends JpaRepository<Comment, Long> {
    // Custom finder method to get all comments for a post, ordered by creation date (oldest first)
    List<Comment> findByPostIdOrderByDateCommentedAsc(Long postId);
}