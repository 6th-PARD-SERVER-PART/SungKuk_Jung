package com.pard.server.hw4_sungkukjung.user;

import com.pard.server.hw4_sungkukjung.comment.Comment;
import com.pard.server.hw4_sungkukjung.like.Like;
import com.pard.server.hw4_sungkukjung.post.Post;
import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Getter @Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String profilePicture;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, unique = true, length = 50)
    private String username;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false, unique = true)
    private String email;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Post> posts;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Like> likes;

    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Comment> comments;

    public void updateUser(UserRequest.UserUpdate userUpdate) {
        this.profilePicture = userUpdate.getProfilePicture() != null ? userUpdate.getProfilePicture() : this.profilePicture;
        this.name = userUpdate.getName() != null ? userUpdate.getName() : this.name;
        this.email = userUpdate.getEmail() != null ? userUpdate.getEmail() : this.email;
        this.password = userUpdate.getPassword() != null ? userUpdate.getPassword() : this.password;
    }

    public int getPostsCount() {
        return this.posts != null ? this.posts.size() : 0;
    }

    public int getLikesCount() {
        return this.likes != null ? this.likes.size() : 0;
    }

    public int getCommentsCount() {
        return this.comments != null ? this.comments.size() : 0;
    }
}
